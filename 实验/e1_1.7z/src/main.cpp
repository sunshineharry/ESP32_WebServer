#include <Arduino.h>
#include <SPIFFS.h>  
#include "log.h"

void setup()
{
    Serial.begin(115200);
    Serial.println();

    LOG_DEBUG("Deafult free size in RAM: ");
    LOGLN(heap_caps_get_free_size(MALLOC_CAP_DEFAULT));
    LOG_DEBUG("Flash size: ");
    LOGLN(ESP.getFlashChipSize());

    SPIFFS.begin(true);
    LOGLN_INFO("Start SPIFFS success!");
}

void loop(){
    vTaskDelay(1000);
}

